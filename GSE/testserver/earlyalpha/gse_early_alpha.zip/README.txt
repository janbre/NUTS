udpserver.py is a simple UDP echo server to play the role of radio

commands.py defines the different commands the user can choose from

messages.py defines the headers for the different kind of packages that can be sent to and from the satellite (check this with the wiki and make sure the satellite side guys agree)

gse.py is where the shit gets real. Just run it and it will present you with a nice little list of available commands
