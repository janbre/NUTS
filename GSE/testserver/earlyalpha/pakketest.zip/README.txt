udpserver.py is a simple UDP echo server

commands.py defines the different commands the user can choose from

messages.py defines the headers for the different kind of packages that can be sent to and from the satellite (check this with the wiki and make sure the satellite side guys agree)

gse.py will present you with a nice little list of available commands

To run, just start udpserver.py and gse.py
